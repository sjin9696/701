﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()//첫실행 한번만
        {
            InitializeComponent();
            System.DateTime.Now.ToString("yyyy");
            Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss"));
            label12.Text = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

        }

        private void label12_Click(object sender, EventArgs e)//라벨 클릭할때마다 
        {
           


        

        }

       
    }
}
