Prior to use the DLL library, please install TSC Windows driver from "Windows driver" directory.
